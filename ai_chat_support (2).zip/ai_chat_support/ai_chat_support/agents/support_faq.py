def handle_faq(message: str) -> str:
    return "This is a general FAQ response. We'll improve this later!"
