def handle_account(message: str) -> str:
    return "Your account balance is ₹2,350. Let us know if you need more help."
