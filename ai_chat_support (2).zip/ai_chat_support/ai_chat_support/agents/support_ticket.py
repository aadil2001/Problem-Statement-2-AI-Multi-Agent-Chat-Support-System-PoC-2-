def handle_ticket(message: str) -> str:
    return "A support ticket has been created for your complaint."
