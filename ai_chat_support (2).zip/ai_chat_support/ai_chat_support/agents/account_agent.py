def handle_account(user_id: str) -> str:
    return f"Here’s your account info: Name: Aadil, ID: {user_id}, Status: Active."
