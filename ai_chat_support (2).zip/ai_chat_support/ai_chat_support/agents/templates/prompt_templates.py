# templates/prompt_templates.py
FAQ_TEMPLATE = "Answer the FAQ based on this query: {query}"
